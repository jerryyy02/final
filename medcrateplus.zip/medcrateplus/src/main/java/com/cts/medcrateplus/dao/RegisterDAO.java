package com.cts.medcrateplus.dao;

import com.cts.medcrateplus.bean.Login;

public interface RegisterDAO {

	public String insertDoctor(Login login);
	public String insertUser(Login login);
}
