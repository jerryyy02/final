package com.cts.medcrateplus.service;

import javax.xml.ws.soap.Addressing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.medcrateplus.bean.Login;
import com.cts.medcrateplus.dao.RegisterDAO;


@Service("RegisterService")
@Transactional(propagation=Propagation.SUPPORTS)
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	RegisterDAO registerDAO;

	
	public String insertDoctor(Login login) {
		// TODO Auto-generated method stub
		return registerDAO.insertDoctor(login);
	}
	
	public String insertUser(Login login) {
		// TODO Auto-generated method stub
		return registerDAO.insertUser(login);
	}

}
