package com.cts.medcrateplus.service;

import com.cts.medcrateplus.bean.Login;

public interface RegisterService {

	public String insertDoctor(Login login);
	public String insertUser(Login login);
}
