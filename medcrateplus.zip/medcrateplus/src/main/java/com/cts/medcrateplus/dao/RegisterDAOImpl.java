package com.cts.medcrateplus.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.medcrateplus.bean.Login;

@Repository("RegisterDAO")
@Transactional
public class RegisterDAOImpl implements RegisterDAO {
	
	@Autowired
	private SessionFactory sessionFacotry;

	@Transactional
	public String insertDoctor(Login login) {
		// TODO Auto-generated method stub
		Session session = null;
		session = sessionFacotry.getCurrentSession();
		session.save(login);
		login.setStatus("0");
		login.setUserType("D");
		return "Success";
	}
	
	@Transactional
	public String insertUser(Login login) {
		// TODO Auto-generated method stub
		Session session = null;
		session = sessionFacotry.getCurrentSession();
		session.save(login);
		login.setStatus("0");
		login.setUserType("U");
		return "Success";
	}

}
