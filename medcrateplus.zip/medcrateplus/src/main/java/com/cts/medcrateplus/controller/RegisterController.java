package com.cts.medcrateplus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.medcrateplus.bean.Login;
import com.cts.medcrateplus.service.RegisterService;

@Controller
public class RegisterController {
	
	@Autowired
	RegisterService registerService;

	@RequestMapping(value="registerDoctor.html", method= RequestMethod.POST)						//PostMapping(value="login.html", method= RequestMethod.GET)
	public ModelAndView insertDoctor(@ModelAttribute Login login){
		ModelAndView modelAndView = new ModelAndView();
		registerService.insertDoctor(login);
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	@RequestMapping(value="registerUser.html", method= RequestMethod.POST)						//PostMapping(value="login.html", method= RequestMethod.GET)
	public ModelAndView insertUser(@ModelAttribute Login login){
		ModelAndView modelAndView = new ModelAndView();
		registerService.insertUser(login);
		modelAndView.setViewName("login");
		return modelAndView;
	}
}
